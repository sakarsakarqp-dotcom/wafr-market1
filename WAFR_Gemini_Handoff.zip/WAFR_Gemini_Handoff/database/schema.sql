-- وَفْر WAFR: initial schema draft for Supabase/PostgreSQL.
-- This is a starting point, NOT a production-ready security review.
-- Apply in a disposable development project first; test every RLS policy.

create extension if not exists pgcrypto;

create type public.app_role as enum ('buyer','seller','admin');
create type public.seller_status as enum ('pending','approved','rejected','suspended');
create type public.product_status as enum ('draft','pending_review','published','rejected','suspended','out_of_stock');
create type public.order_status as enum ('pending','confirmed','processing','shipped','delivered','completed','cancelled','returned','disputed');
create type public.review_status as enum ('published','hidden','reported');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  phone text,
  preferred_locale text not null default 'ar',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Roles should be assigned by trusted server/admin workflows only.
create table public.user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null default 'buyer',
  created_at timestamptz not null default now(),
  primary key(user_id, role)
);

create table public.seller_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  legal_or_public_name text not null,
  contact_phone text not null,
  business_type text not null,
  notes text,
  status public.seller_status not null default 'pending',
  reviewed_by uuid references auth.users(id),
  reviewed_at timestamptz,
  review_note text,
  created_at timestamptz not null default now()
);

create table public.stores (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete restrict,
  name text not null,
  slug text not null unique,
  description text,
  logo_path text,
  banner_path text,
  status public.seller_status not null default 'pending',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.categories (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid references public.categories(id) on delete set null,
  name_ar text not null,
  slug text not null unique,
  description text,
  is_active boolean not null default true,
  sort_order integer not null default 0,
  supports_cart boolean not null default true,
  created_at timestamptz not null default now()
);

-- Dynamic attributes, e.g. vehicle year/mileage or phone storage.
create table public.category_attributes (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.categories(id) on delete cascade,
  key text not null,
  label_ar text not null,
  data_type text not null check (data_type in ('text','number','boolean','select','date')),
  options jsonb not null default '[]'::jsonb,
  is_required boolean not null default false,
  sort_order integer not null default 0,
  unique(category_id, key)
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid not null references public.stores(id) on delete restrict,
  category_id uuid not null references public.categories(id) on delete restrict,
  name text not null,
  slug text not null,
  description text not null default '',
  condition text not null default 'new' check (condition in ('new','used','refurbished')),
  price numeric(14,2) not null check (price >= 0),
  wholesale_price numeric(14,2) check (wholesale_price is null or wholesale_price >= 0),
  wholesale_min_qty integer check (wholesale_min_qty is null or wholesale_min_qty > 0),
  currency_code text not null default 'SYP',
  stock_quantity integer check (stock_quantity is null or stock_quantity >= 0),
  delivery_price numeric(14,2) check (delivery_price is null or delivery_price >= 0),
  delivery_included boolean not null default false,
  attributes jsonb not null default '{}'::jsonb,
  status public.product_status not null default 'draft',
  supports_cart boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(store_id, slug)
);

create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  storage_path text not null,
  alt_text text,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  recipient_name text not null,
  phone text not null,
  country_code text not null default 'SY',
  region text,
  city text not null,
  address_line text not null,
  notes text,
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigint generated always as identity unique,
  buyer_id uuid not null references auth.users(id) on delete restrict,
  status public.order_status not null default 'pending',
  currency_code text not null default 'SYP',
  subtotal numeric(14,2) not null default 0 check (subtotal >= 0),
  delivery_total numeric(14,2) not null default 0 check (delivery_total >= 0),
  discount_total numeric(14,2) not null default 0 check (discount_total >= 0),
  grand_total numeric(14,2) not null default 0 check (grand_total >= 0),
  payment_method text not null default 'manual',
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','pending','paid','refunded','failed')),
  delivery_address_snapshot jsonb not null default '{}'::jsonb,
  buyer_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  store_id uuid not null references public.stores(id) on delete restrict,
  product_id uuid references public.products(id) on delete set null,
  product_name_snapshot text not null,
  unit_price numeric(14,2) not null check (unit_price >= 0),
  quantity integer not null check (quantity > 0),
  delivery_fee numeric(14,2) not null default 0 check (delivery_fee >= 0),
  line_total numeric(14,2) not null check (line_total >= 0),
  status public.order_status not null default 'pending',
  created_at timestamptz not null default now()
);

create table public.commission_settings (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.categories(id) on delete cascade,
  store_id uuid references public.stores(id) on delete cascade,
  rate_percent numeric(5,2) not null check (rate_percent >= 0 and rate_percent <= 100),
  is_active boolean not null default true,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check (category_id is not null or store_id is not null or true)
);

create table public.commission_ledger (
  id uuid primary key default gen_random_uuid(),
  order_item_id uuid not null unique references public.order_items(id) on delete restrict,
  store_id uuid not null references public.stores(id) on delete restrict,
  gross_amount numeric(14,2) not null check (gross_amount >= 0),
  rate_percent numeric(5,2) not null check (rate_percent >= 0 and rate_percent <= 100),
  commission_amount numeric(14,2) not null check (commission_amount >= 0),
  currency_code text not null default 'SYP',
  status text not null default 'pending' check (status in ('pending','payable','settled','reversed','disputed')),
  created_at timestamptz not null default now(),
  settled_at timestamptz
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  buyer_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  order_item_id uuid not null unique references public.order_items(id) on delete restrict,
  rating integer not null check (rating between 1 and 5),
  body text,
  status public.review_status not null default 'published',
  created_at timestamptz not null default now(),
  unique(buyer_id, product_id, order_item_id)
);

create table public.reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references auth.users(id) on delete set null,
  product_id uuid references public.products(id) on delete cascade,
  store_id uuid references public.stores(id) on delete cascade,
  reason text not null,
  details text,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  handled_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check (product_id is not null or store_id is not null)
);

create table public.audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index products_status_category_idx on public.products(status, category_id);
create index products_store_status_idx on public.products(store_id, status);
create index orders_buyer_created_idx on public.orders(buyer_id, created_at desc);
create index order_items_store_status_idx on public.order_items(store_id, status);
create index reviews_product_status_idx on public.reviews(product_id, status);

-- Helper function: do not let client-controlled profile fields determine admin privileges.
create or replace function public.has_role(required_role public.app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles ur where ur.user_id = auth.uid() and ur.role = required_role); $$;
revoke all on function public.has_role(public.app_role) from public;
grant execute on function public.has_role(public.app_role) to authenticated;

-- Enable RLS. Policies below are a conservative starter and need project-specific tests.
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.seller_applications enable row level security;
alter table public.stores enable row level security;
alter table public.categories enable row level security;
alter table public.category_attributes enable row level security;
alter table public.products enable row level security;
alter table public.product_images enable row level security;
alter table public.addresses enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.commission_settings enable row level security;
alter table public.commission_ledger enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;
alter table public.audit_logs enable row level security;

-- Profiles: user sees/updates own profile; admin can read all through trusted admin role.
create policy profiles_select_own_or_admin on public.profiles for select to authenticated using (id = auth.uid() or public.has_role('admin'));
create policy profiles_update_own on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_insert_own on public.profiles for insert to authenticated with check (id = auth.uid());

-- Roles are readable by the user for their own account; role writes must be server/admin controlled.
create policy user_roles_select_own_or_admin on public.user_roles for select to authenticated using (user_id = auth.uid() or public.has_role('admin'));

create policy seller_applications_insert_own on public.seller_applications for insert to authenticated with check (user_id = auth.uid());
create policy seller_applications_select_own_or_admin on public.seller_applications for select to authenticated using (user_id = auth.uid() or public.has_role('admin'));
create policy seller_applications_admin_update on public.seller_applications for update to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));

create policy stores_public_approved_read on public.stores for select to anon, authenticated using (status = 'approved' or owner_id = auth.uid() or public.has_role('admin'));
create policy stores_owner_insert_pending on public.stores for insert to authenticated with check (owner_id = auth.uid() and status = 'pending');
create policy stores_owner_update on public.stores for update to authenticated using (owner_id = auth.uid() or public.has_role('admin')) with check (owner_id = auth.uid() or public.has_role('admin'));

create policy categories_public_read on public.categories for select to anon, authenticated using (is_active = true or public.has_role('admin'));
create policy categories_admin_all on public.categories for all to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));
create policy category_attributes_public_read on public.category_attributes for select to anon, authenticated using (exists(select 1 from public.categories c where c.id = category_id and c.is_active = true) or public.has_role('admin'));
create policy category_attributes_admin_all on public.category_attributes for all to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));

create policy products_public_published_read on public.products for select to anon, authenticated using (status = 'published' or exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()) or public.has_role('admin'));
create policy products_seller_insert on public.products for insert to authenticated with check (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid() and s.status = 'approved'));
create policy products_seller_update on public.products for update to authenticated using (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()) or public.has_role('admin')) with check (exists(select 1 from public.stores s where s.id = store_id and s.owner_id = auth.uid()) or public.has_role('admin'));
create policy products_admin_delete on public.products for delete to authenticated using (public.has_role('admin'));

create policy product_images_public_read_for_published on public.product_images for select to anon, authenticated using (exists(select 1 from public.products p where p.id = product_id and p.status = 'published') or exists(select 1 from public.products p join public.stores s on s.id=p.store_id where p.id=product_id and s.owner_id=auth.uid()) or public.has_role('admin'));
create policy product_images_seller_insert on public.product_images for insert to authenticated with check (exists(select 1 from public.products p join public.stores s on s.id=p.store_id where p.id=product_id and s.owner_id=auth.uid()));
create policy product_images_seller_delete on public.product_images for delete to authenticated using (exists(select 1 from public.products p join public.stores s on s.id=p.store_id where p.id=product_id and s.owner_id=auth.uid()) or public.has_role('admin'));

create policy addresses_own_all on public.addresses for all to authenticated using (user_id=auth.uid() or public.has_role('admin')) with check (user_id=auth.uid() or public.has_role('admin'));
create policy orders_buyer_read on public.orders for select to authenticated using (buyer_id=auth.uid() or public.has_role('admin'));
create policy orders_buyer_insert on public.orders for insert to authenticated with check (buyer_id=auth.uid());
-- Order status/amount updates should be performed through trusted server functions, not broad client updates.
create policy order_items_buyer_or_seller_read on public.order_items for select to authenticated using (exists(select 1 from public.orders o where o.id=order_id and o.buyer_id=auth.uid()) or exists(select 1 from public.stores s where s.id=store_id and s.owner_id=auth.uid()) or public.has_role('admin'));
-- Do not grant general client insert/update/delete policies for order_items; create orders through a server-side transaction.

create policy commission_settings_admin_read on public.commission_settings for select to authenticated using (public.has_role('admin'));
create policy commission_settings_admin_write on public.commission_settings for all to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));
create policy commission_ledger_admin_read on public.commission_ledger for select to authenticated using (public.has_role('admin'));
create policy commission_ledger_store_read on public.commission_ledger for select to authenticated using (exists(select 1 from public.stores s where s.id=store_id and s.owner_id=auth.uid()));
-- Ledger writes only via trusted server function/transaction.

create policy reviews_public_read on public.reviews for select to anon, authenticated using (status='published' or buyer_id=auth.uid() or public.has_role('admin'));
create policy reviews_buyer_insert on public.reviews for insert to authenticated with check (buyer_id=auth.uid() and exists(select 1 from public.order_items oi join public.orders o on o.id=oi.order_id where oi.id=order_item_id and o.buyer_id=auth.uid() and o.status='completed' and oi.product_id=product_id));
create policy reviews_buyer_update_own on public.reviews for update to authenticated using (buyer_id=auth.uid()) with check (buyer_id=auth.uid());

create policy reports_insert_signed_in on public.reports for insert to authenticated with check (reporter_id=auth.uid());
create policy reports_own_or_admin_read on public.reports for select to authenticated using (reporter_id=auth.uid() or public.has_role('admin'));
create policy reports_admin_update on public.reports for update to authenticated using (public.has_role('admin')) with check (public.has_role('admin'));
create policy audit_logs_admin_read on public.audit_logs for select to authenticated using (public.has_role('admin'));
-- Audit-log inserts should be server-side only.

-- IMPORTANT follow-up tasks for Gemini/developer:
-- 1. Review all policies with real tests, especially role escalation, store status updates, and review ownership.
-- 2. Create server-side transactional order creation with stock locking and authoritative totals.
-- 3. Add secure state-transition functions for order_items/orders and idempotent commission posting.
-- 4. Create Supabase Storage buckets and storage.objects policies for store/product images.
-- 5. Ensure ordinary sellers cannot self-approve stores or publish products without the configured review workflow.
-- 6. Add updated_at triggers, search indexes, rate limiting, audit events, and migration rollback strategy.
